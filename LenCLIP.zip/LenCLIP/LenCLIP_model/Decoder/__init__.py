"""LenCLIP segmentation decoder."""
